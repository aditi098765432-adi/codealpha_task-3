# FitFlow — Fitness Tracker

A ready-to-upload, mobile-friendly fitness tracker made with plain HTML, CSS and JavaScript.

## Features
- Daily steps and active-minute tracking
- Water glass tracker
- Workout/activity log
- Gentle daily habit checklist
- Progress bars and daily goal ring
- Saves data in the browser using localStorage
- Automatically starts a fresh daily dashboard on a new date

## Upload to GitHub
1. Create or open a GitHub repository.
2. Choose **Add file → Upload files**.
3. Upload `index.html` (and optionally this README).
4. Commit the changes.
5. Open **Settings → Pages**.
6. Under Build and deployment, choose **Deploy from a branch**.
7. Select `main` and `/ (root)`, then Save.
8. After GitHub Pages publishes, open the website link shown there.

No installation or backend is required. Data is stored locally in the browser on the device being used.
